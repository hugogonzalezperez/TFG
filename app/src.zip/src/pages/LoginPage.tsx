import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Label, Input } from '../components/ui';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AnimatedLoader } from '../components/loaders/animatedLoader';
import { ErrorMessage } from '../components/ui/errorMessage';
import { AuthLayout, OAuthButtons, FormInput } from '../components/shared';

export function Login() {
  const navigate = useNavigate();
  const { login, loginWithGoogle, loginWithFacebook, loading } = useAuth();

  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      await login({ email, password });
      navigate('/');
    } catch (err: any) {
      console.error('Login error:', err);
      setIsSubmitting(false);
      // Aquí es donde el error lanzado desde el contexto es atrapado
      console.error("Login page error:", err.message);
      setError(err.message); // ¡Guardamos el error para mostrarlo!
    }
  };

  const handleGoogleLogin = async () => {
    setError(null);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setError(err.message || 'Error al iniciar sesión con Google');
    }
  };

  const handleFacebookLogin = async () => {
    setError(null);
    try {
      await loginWithFacebook();
    } catch (err: any) {
      setError(err.message || 'Error al iniciar sesión con Facebook');
    }
  };

  return (
    <div className="relative min-h-screen">
      {(isSubmitting || (loading && !error)) && (
        <AnimatedLoader message="Iniciando sesión..." />
      )}

      <AuthLayout
        title="¡Bienvenido de nuevo!"
        subtitle="Encuentra tu plaza perfecta en Tenerife"
        footer={
          <p className="text-sm text-muted-foreground">
            ¿No tienes cuenta?{' '}
            <button
              onClick={() => navigate('/signup')}
              className="text-primary hover:underline font-medium"
              disabled={isSubmitting || loading}
            >
              Regístrate gratis
            </button>
          </p>
        }
      >
        <ErrorMessage message={error || ''} onClose={() => setError(null)} />

        <form onSubmit={handleLogin} className="space-y-6">
          <FormInput
            id="email"
            label="Email"
            type="email"
            placeholder="tu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            icon={Mail}
            required
            disabled={isSubmitting || loading}
          />

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Contraseña</Label>
              <button
                type="button"
                className="text-sm text-primary hover:underline"
                disabled={isSubmitting || loading}
              >
                ¿Olvidaste tu contraseña?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-10"
                required
                disabled={isSubmitting || loading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                disabled={isSubmitting || loading}
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-white h-12"
            disabled={isSubmitting || loading}
          >
            {isSubmitting ? 'Iniciando sesión...' : 'Iniciar sesión'}
          </Button>

          <OAuthButtons
            onGoogleClick={handleGoogleLogin}
            onFacebookClick={handleFacebookLogin}
            disabled={isSubmitting || loading}
          />
        </form>
      </AuthLayout>
    </div>
  );
}