import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Input, Label, Button, Checkbox } from '../components/ui';
import { User, Mail, Lock, Eye, EyeOff, Phone } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ErrorMessage } from '../components/ui/errorMessage';
import { AuthLayout, OAuthButtons, FormInput } from '../components/shared';

export function SignUp() {
  const navigate = useNavigate();
  const { register, loginWithGoogle, loginWithFacebook, loading } = useAuth();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    isOwner: false,
    acceptTerms: false,
  });

  const validateForm = (): string | null => {
    if (formData.password.length < 8) {
      return 'La contraseña debe tener al menos 8 caracteres';
    }

    if (formData.password !== formData.confirmPassword) {
      return 'Las contraseñas no coinciden';
    }

    if (!formData.acceptTerms) {
      return 'Debes aceptar los términos y condiciones';
    }

    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const validationError = validateForm();
    if (validationError) {
      console.log('Validation error:', validationError);
      setError(validationError);
      return;
    }

    setIsSubmitting(true);

    const fullName = `${formData.name} ${formData.surname}`.trim();

    try {
      await register({
        email: formData.email,
        password: formData.password,
        name: fullName,
        phone: formData.phone,
        isOwner: formData.isOwner
      });

      navigate('/');
    } catch (err: any) {
      console.error('Registration error:', err);
      setIsSubmitting(false);

      const msg = err.message === 'User already registered'
        ? 'Este correo ya está registrado'
        : err.message;

      setError(msg || 'Error al registrarse');
    }
  };

  const handleGoogleSignUp = async () => {
    setError(null);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setError(err.message || 'Error al registrarse con Google');
    }
  };

  const handleFacebookSignUp = async () => {
    setError(null);
    try {
      await loginWithFacebook();
    } catch (err: any) {
      setError(err.message || 'Error al registrarse con Facebook');
    }
  };

  return (
    <AuthLayout
      title="Crea tu cuenta"
      subtitle="Únete a la comunidad de Parky"
      footer={
        <p className="text-sm text-muted-foreground">
          ¿Ya tienes cuenta?{' '}
          <button
            onClick={() => navigate('/login')}
            className="text-primary hover:underline font-medium"
            disabled={isSubmitting || loading}
          >
            Inicia sesión
          </button>
        </p>
      }
    >
      <ErrorMessage message={error || ''} onClose={() => setError(null)} />

      <form onSubmit={handleSubmit} className="space-y-5">
        <FormInput
          id="name"
          label="Nombre"
          placeholder="Juan"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          icon={User}
          required
          disabled={isSubmitting || loading}
        />

        <FormInput
          id="surname"
          label="Apellidos"
          placeholder="Pérez"
          value={formData.surname}
          onChange={(e) => setFormData({ ...formData, surname: e.target.value })}
          icon={User}
          required
          disabled={isSubmitting || loading}
        />

        <FormInput
          id="email"
          label="Email"
          type="email"
          placeholder="tu@email.com"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          icon={Mail}
          required
          disabled={isSubmitting || loading}
        />

        <FormInput
          id="phone"
          label="Teléfono (opcional)"
          type="tel"
          placeholder="+34 600 000 000"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          icon={Phone}
          disabled={isSubmitting || loading}
        />

        <FormInput
          id="password"
          label="Contraseña"
          type={showPassword ? 'text' : 'password'}
          placeholder="Mínimo 8 caracteres"
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          icon={Lock}
          iconRight={showPassword ? EyeOff : Eye}
          onIconClick={() => setShowPassword(!showPassword)}
          required
          minLength={8}
          disabled={isSubmitting || loading}
        />

        <FormInput
          id="confirmPassword"
          label="Confirmar contraseña"
          type={showConfirmPassword ? 'text' : 'password'}
          placeholder="Repite tu contraseña"
          value={formData.confirmPassword}
          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
          icon={Lock}
          iconRight={showConfirmPassword ? EyeOff : Eye}
          onIconClick={() => setShowConfirmPassword(!showConfirmPassword)}
          required
          disabled={isSubmitting || loading}
        />

        <div className="flex items-center space-x-2 bg-muted/50 p-3 rounded-lg">
          <Checkbox
            id="isOwner"
            checked={formData.isOwner}
            onCheckedChange={(checked: any) => setFormData({ ...formData, isOwner: checked as boolean })}
            disabled={isSubmitting || loading}
          />
          <label
            htmlFor="isOwner"
            className="text-sm cursor-pointer leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Quiero alquilar mi plaza de aparcamiento
          </label>
        </div>

        <div className="flex items-start space-x-2">
          <Checkbox
            id="terms"
            checked={formData.acceptTerms}
            onCheckedChange={(checked: any) => setFormData({ ...formData, acceptTerms: checked as boolean })}
            required
            disabled={isSubmitting || loading}
          />
          <label
            htmlFor="terms"
            className="text-sm cursor-pointer leading-relaxed peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-muted-foreground"
          >
            Acepto los{' '}
            <a href="#" className="text-primary hover:underline">
              Términos de Servicio
            </a>{' '}
            y la{' '}
            <a href="#" className="text-primary hover:underline">
              Política de Privacidad
            </a>
          </label>
        </div>

        <Button
          type="submit"
          className="w-full bg-accent hover:bg-accent/90 text-white h-12"
          disabled={isSubmitting || loading}
        >
          {isSubmitting ? 'Creando cuenta...' : 'Crear cuenta'}
        </Button>

        <OAuthButtons
          onGoogleClick={handleGoogleSignUp}
          onFacebookClick={handleFacebookSignUp}
          disabled={isSubmitting || loading}
        />
      </form>
    </AuthLayout>
  );
}